<?php
// local/automatic_badges/classes/hook_callbacks.php

namespace local_automatic_badges;

defined('MOODLE_INTERNAL') || die();

/**
 * Hook callbacks for local_automatic_badges.
 */
class hook_callbacks {

    /**
     * Inject a "Volver a Automatic Badges" button on Moodle badge pages.
     *
     * @param \core\hook\output\before_footer_html_generation $hook
     */
    public static function before_footer(\core\hook\output\before_footer_html_generation $hook): void {
        global $PAGE;

        // Only act on badge pages within a course context.
        $pagepath = $PAGE->url->get_path();
        if (strpos($pagepath, '/badges/') === false) {
            return;
        }

        $courseid = $PAGE->url->get_param('courseid');
        if (!$courseid && $PAGE->context && $PAGE->context->contextlevel == CONTEXT_COURSE) {
            $courseid = $PAGE->context->instanceid;
        }
        if (!$courseid) {
            return;
        }

        $returnurl = new \moodle_url('/local/automatic_badges/course_settings.php', ['id' => $courseid, 'tab' => 'badges']);

        $PAGE->requires->js_amd_inline("
            require(['jquery'], function($) {
                var returnUrl = '" . $returnurl->out(false) . "';

                // Target the form action buttons area
                var actionArea = $('#fitem_id_buttonar, .form-group .fsubmit, [data-groupname=\"buttonar\"]');

                if (actionArea.length) {
                    var backBtn = $('<a>')
                        .attr('href', returnUrl)
                        .addClass('btn btn-outline-secondary ml-2')
                        .html('<i class=\"fa fa-arrow-left mr-1\"></i> Volver a Automatic Badges');
                    actionArea.find('.form-inline, .felement, .fdefaultcustom, div').last().append(backBtn);
                }

                // Also add a visible link near the top of the page as a breadcrumb-style return
                var heading = $('#region-main h2, #region-main .h2').first();
                if (heading.length) {
                    var topLink = $('<a>')
                        .attr('href', returnUrl)
                        .addClass('btn btn-sm btn-outline-secondary mb-3 d-inline-block')
                        .html('<i class=\"fa fa-arrow-left mr-1\"></i> Volver a Automatic Badges');
                    heading.before(topLink);
                }
            });
        ");
    }
}
