<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_automatic_badges';
$plugin->version = 2026031104;
$plugin->requires = 2024100700; // Moodle 4.5+
$plugin->maturity = MATURITY_RC;
$plugin->release = '0.5.4';
