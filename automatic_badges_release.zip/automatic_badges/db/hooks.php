<?php
// local/automatic_badges/db/hooks.php

defined('MOODLE_INTERNAL') || die();

$callbacks = [
    [
        'hook' => core\hook\output\before_footer_html_generation::class,
        'callback' => 'local_automatic_badges\hook_callbacks::before_footer',
        'priority' => 0,
    ],
];
